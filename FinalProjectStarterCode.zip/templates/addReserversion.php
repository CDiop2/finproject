<html>

<head>
    <title>Add Reservation</title>
</head>


<body>
    <h1 class="lgHeading">Add Reservation</h1>
    <form method="POST" action="index.php?action=addReservation">
        <label>Customer ID: </label>
        <input type="text" name="customer_id"><br>
        Reservation Time:
        <input type="datetime-local" name="reservation_time"><br>
        Number of Guests:
        <input type="number" name="number_of_guests"><br>
        Special Requests:
        <textarea name="special_requests"></textarea><br>
        <button type="submit" class="mainBtn">Submit</button>
    </form>
    <a href="index.php">Back to Home</a>

</body>

</html>